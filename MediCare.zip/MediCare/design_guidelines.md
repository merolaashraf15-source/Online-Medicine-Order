# Design Guidelines: Online Medicine Order System

## Design Approach

**Selected Framework:** Material Design with Healthcare Adaptations
- **Rationale:** Medical applications require trust, clarity, and accessibility. Material Design provides well-tested patterns for form inputs, data display, and information hierarchy while maintaining a professional, calming aesthetic appropriate for healthcare.
- **Key Principles:** Trust through clarity, accessible information architecture, clean visual hierarchy, responsive efficiency

---

## Typography System

**Font Stack:** 
- Primary: Inter or Poppins (Google Fonts)
- Fallback: system-ui, sans-serif

**Hierarchy:**
- H1 (Page Titles): 2.5rem, font-weight 700
- H2 (Section Headers): 2rem, font-weight 600
- H3 (Card/Component Titles): 1.5rem, font-weight 600
- Body Text: 1rem, font-weight 400, line-height 1.6
- Labels/Small Text: 0.875rem, font-weight 500
- Button Text: 1rem, font-weight 600

---

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16
- Component padding: p-6 to p-8
- Section spacing: py-12 to py-16
- Card margins: mb-6
- Form field gaps: gap-6

**Container Strategy:**
- Max-width: max-w-6xl for main content
- Form containers: max-w-2xl centered
- Order list: max-w-4xl

**Grid Usage:**
- Homepage features: 3-column grid on desktop (lg:grid-cols-3), single column mobile
- Order cards: single column stack with consistent spacing

---

## Component Library

### Homepage
**Hero Section (60vh):**
- Centered content with healthcare imagery (stethoscope, pills, or medical consultation)
- Large headline: "Your Trusted Online Medicine Partner"
- Subheadline explaining service
- Two CTAs: "Order Medicine" (primary) and "View Orders" (secondary)
- Buttons on hero image must have backdrop-blur-md backgrounds with semi-transparent white overlay

**Features Section:**
- 3-column grid showcasing: "Easy Ordering", "Fast Service", "Secure Storage"
- Each card: Icon (from Heroicons - medical icons), title, short description
- Cards with subtle shadow elevation, rounded corners (rounded-xl)

**Trust Indicators:**
- Brief text section about service reliability
- Could include stats or simple badges

### Order Form Page
**Form Container:**
- Centered card with generous padding (p-8)
- Page title at top
- Form fields stacked vertically with gap-6

**Input Fields:**
- Full-width inputs with clear labels above
- Height: h-12
- Border: Subtle border with focus ring states
- Rounded: rounded-lg
- All fields required with clear validation states

**Field Structure:**
1. Customer Name (text input)
2. Phone Number (tel input with pattern validation)
3. Medicine Name (text input)

**Submit Button:**
- Full-width or prominent right-aligned
- Height: h-12
- Icon: Plus or shopping cart icon from Heroicons

### Orders Display Page
**Layout:**
- Page title with count badge ("All Orders (5)")
- Order cards in vertical stack
- Each card displays: Customer name, phone, medicine, timestamp
- Empty state message if no orders exist

**Order Card Design:**
- Elevated card with border
- Grid layout for data fields
- Small delete/remove action (icon button)
- Consistent height and padding (p-6)

### Navigation
**Header:**
- Fixed or sticky top navigation
- Logo/app name on left
- Navigation links: "Home", "Order Medicine", "View Orders"
- Medical cross or pill icon in header
- Clean, minimal design with subtle bottom border

**Footer:**
- Centered text with disclaimer about demo/educational purpose
- Padding: py-8
- Small text about LocalStorage usage

---

## Interactions & States

**Form Validation:**
- Error messages below inputs in small text
- Success state with green accent when submitted
- Clear visual feedback for required fields

**Button States:**
- Primary buttons: Solid fill with hover lift effect (subtle transform)
- Secondary buttons: Outline style
- Disabled states with reduced opacity

**Loading States:**
- Simple spinner or "Submitting..." text when processing form
- Success confirmation message after submission

---

## Icons

**Library:** Heroicons (via CDN)
**Usage:**
- Medical cross for branding
- Plus icon for "Add Order"
- List icon for "View Orders"
- Trash icon for delete actions
- Check circle for success states
- Alert circle for validation errors

---

## Images Section

**Homepage Hero Image:**
- **Description:** Professional medical/pharmacy stock photo - clean, modern pharmacy setting or hands holding medication packages. Image should convey trust, care, and professionalism. Avoid clinical/sterile hospital imagery; prefer warm, approachable healthcare visuals.
- **Placement:** Full-width hero section background with overlay gradient for text readability
- **Treatment:** Subtle overlay (rgba black 30-40% opacity) to ensure text contrast
- **Note:** Hero image is INCLUDED - essential for establishing trust in medical context

**Feature Icons:**
- Use Heroicons medical-themed icons rather than images
- Consistency over photographs for feature cards

---

## Accessibility Notes

- Maintain WCAG AA contrast ratios throughout
- All form inputs have associated labels
- Focus indicators clearly visible on all interactive elements
- Semantic HTML structure with proper heading hierarchy
- Error messages announced to screen readers

---

This design creates a trustworthy, professional medical ordering interface that prioritizes usability and clarity while maintaining visual appeal appropriate for healthcare applications.