# MediOrder - Online Medicine Order System

## Overview

MediOrder is a web-based medicine ordering platform that allows users to place medicine orders online. The application features a clean, healthcare-focused interface with a homepage showcasing the service, an order form for submitting medicine requests, and an orders list for viewing submitted orders. Built with modern web technologies, the application emphasizes trust, clarity, and accessibility - key principles for medical applications.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, providing fast HMR and optimized production builds
- **Wouter** for lightweight client-side routing (alternatives like React Router were avoided to minimize bundle size)

**UI Component System**
- **shadcn/ui** components built on Radix UI primitives for accessible, customizable components
- **Tailwind CSS** for utility-first styling with custom design tokens
- Material Design principles adapted for healthcare applications, emphasizing trust and clarity
- Component library includes forms, cards, buttons, dialogs, and navigation elements

**State Management**
- **TanStack Query (React Query)** for server state management and data fetching
- **React Hooks** (useState, useEffect) for local component state
- **localStorage** for client-side persistence of medicine orders (no backend database integration currently)

**Design System**
- Custom color palette with HSL-based theming supporting light/dark modes
- Typography system using Inter/Poppins fonts with defined hierarchy (H1-H3, body, labels)
- Spacing primitives based on Tailwind's scale (2, 4, 6, 8, 12, 16)
- Responsive grid layouts: 3-column desktop, single-column mobile

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript for the HTTP server
- Modular route registration system with separation of concerns
- Middleware pipeline for JSON parsing, logging, and request tracking
- Static file serving for production builds

**Development vs Production**
- Development mode uses Vite middleware for HMR and live reloading
- Production mode serves pre-built static assets from dist/public
- Environment-specific configuration via NODE_ENV

**Storage Layer**
- **Interface-based design** (IStorage) allowing swappable implementations
- **MemStorage** in-memory implementation for development/testing
- Database schema defined using Drizzle ORM (prepared for PostgreSQL integration)
- Currently stores data client-side in localStorage; backend storage ready for activation

### Data Storage Solutions

**Current Implementation**
- Client-side localStorage for order persistence
- In-memory Map structure on server (MemStorage class)
- Type-safe order models with TypeScript interfaces

**Prepared Infrastructure**
- **Drizzle ORM** configured for PostgreSQL dialect
- **Neon Serverless** driver for database connections
- Schema definitions in shared/schema.ts with Zod validation
- Migration system configured via drizzle-kit
- Session storage setup with connect-pg-simple (ready for user authentication)

**Data Models**
- User schema with username/password fields
- Order model with customer name, phone, medicine name, and timestamp
- Zod schemas for runtime validation using drizzle-zod integration

### Authentication & Authorization

**Prepared but Not Activated**
- User table schema defined in database
- Password storage field available (note: should be hashed before production use)
- No active authentication middleware or session management currently implemented
- Infrastructure ready for passport.js or similar authentication strategies

### Form Handling & Validation

**Client-Side**
- React Hook Form with @hookform/resolvers for form state management
- Custom validation logic for customer name (min 2 chars), phone (regex pattern), and medicine name
- Real-time error feedback with inline error messages
- Controlled inputs with state management

**Validation Patterns**
- Phone validation: `/^[\d\s\-+()]{7,15}$/` allowing international formats
- Name validation: minimum 2 characters, required fields
- Medicine validation: minimum 2 characters, required

### Routing Architecture

**Client-Side Routes**
- `/` - Homepage with hero section and feature cards
- `/order` - Medicine order form
- `/orders` - List of submitted orders
- `/` - 404 fallback for unmatched routes

**SPA Configuration**
- All routes serve the same index.html in production
- Client-side routing handles navigation without page reloads
- Fallback routing catches unknown paths and shows 404 component

### Build System

**Development Build**
- TSX for running TypeScript server code directly
- Vite dev server with HMR for client code
- Separate client and server processes

**Production Build**
- esbuild bundles server code into single dist/index.cjs file
- Selective bundling: allowlisted dependencies bundled, others external
- Vite builds client to dist/public with code splitting and optimization
- Asset fingerprinting and minification enabled

## External Dependencies

### UI & Styling
- **@radix-ui/** - Accessible component primitives (accordion, dialog, dropdown, etc.)
- **tailwindcss** - Utility-first CSS framework
- **class-variance-authority** - Type-safe component variants
- **lucide-react** - Icon library
- **embla-carousel-react** - Carousel/slider component

### State & Data Fetching
- **@tanstack/react-query** - Async state management and caching
- **wouter** - Lightweight routing library

### Database & ORM
- **drizzle-orm** - TypeScript ORM for SQL databases
- **@neondatabase/serverless** - Serverless PostgreSQL driver
- **drizzle-zod** - Zod schema integration for validation

### Forms & Validation
- **react-hook-form** - Form state management
- **@hookform/resolvers** - Validation resolvers
- **zod** - Schema validation library

### Build Tools
- **vite** - Frontend build tool and dev server
- **esbuild** - JavaScript bundler for server code
- **tsx** - TypeScript execution for Node.js

### Replit-Specific
- **@replit/vite-plugin-runtime-error-modal** - Error overlay
- **@replit/vite-plugin-cartographer** - Development tooling
- **@replit/vite-plugin-dev-banner** - Dev environment banner

### Fonts
- **Google Fonts** - Inter, Poppins, DM Sans, Fira Code, Geist Mono (loaded via CDN)

### Potential Future Integrations
The package.json includes dependencies suggesting planned features:
- **express-session** with **connect-pg-simple** - Session management
- **passport** - Authentication framework
- **nodemailer** - Email notifications
- **stripe** - Payment processing
- **multer** - File uploads
- **openai** / **@google/generative-ai** - AI integrations
- **ws** - WebSocket support
- **xlsx** - Spreadsheet handling